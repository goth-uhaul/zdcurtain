from vcolorpicker import getColor

def main():
    print(getColor())


if __name__ == '__main__':
    main()